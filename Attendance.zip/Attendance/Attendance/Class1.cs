﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Attendance
{
    internal class Class1
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\CSharp\windows\Attendance\Attendance\bin\Debug\atten.mdf;Integrated Security=True;Connect Timeout=30");
    }
}
