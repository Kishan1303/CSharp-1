﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attendance
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        public void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            textBox3.Text = "";
            textBox1.Focus();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }


        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text != "" && comboBox1.Text != "" && comboBox2.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                string sql = "Select * from stud where course='" + comboBox1.Text + "' and div='" + comboBox2.Text + "' and roll='" + textBox2.Text + "'";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sql, Class1.cn);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);
                if (dataTable.Rows.Count > 0)
                {
                    MessageBox.Show("taken Roll No");
                }
                else
                {

                    string ins = "insert into stud values('" + textBox1.Text + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
                    SqlDataAdapter adapter = new SqlDataAdapter(ins, Class1.cn);
                    DataTable dt = new DataTable();
                    int a = adapter.Fill(dt);
                    if (a == 0)
                    {
                        MessageBox.Show("Done");
                    }
                    else
                    {
                        MessageBox.Show("Not");
                    }

                }
            }
        }








        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string sql = "Select * from stud where course='" + comboBox1.Text + "' and div='" + comboBox2.Text + "' and roll='" + textBox2.Text + "'";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sql, Class1.cn);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            if (dataTable.Rows.Count > 0)
            {
                MessageBox.Show("taken");
            }
           
      



        }
    }

}
