﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attendance
{
    public partial class Form3 : Form
    {
        string date = System.DateTime.Now.ToShortDateString();
        public Form3()
        {
            InitializeComponent();
        }

     

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        public void clear()
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            comboBox4.Text = "";


        }

      
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select * from stud where course='" + comboBox1.Text + "' and div='" + comboBox2.Text + "' ";
            SqlDataAdapter adapter = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox3.DataSource = dt;
            comboBox3.DisplayMember = "roll";
           // clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "Select * from att where course='" + comboBox1.Text + "' and div='" + comboBox2.Text + "' and rol ='" + comboBox3.Text + "' and date ='" + date + "'";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sql, Class1.cn);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            if (dataTable.Rows.Count > 0)
            {
                MessageBox.Show("attendance done !");
                clear();
            }

            else
            {
                string ins = "insert into att values('" + comboBox1.Text + "','" + comboBox2.Text + "','" + comboBox3.Text + "','" + comboBox4.Text + "','" + date + "')";
                SqlDataAdapter sqlDataAdapter1 = new SqlDataAdapter(ins, Class1.cn);
                DataTable dataTable1 = new DataTable();
                sqlDataAdapter1.Fill(dataTable1);
                MessageBox.Show("Ready Bhura !");
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
