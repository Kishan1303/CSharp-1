﻿delete from list
