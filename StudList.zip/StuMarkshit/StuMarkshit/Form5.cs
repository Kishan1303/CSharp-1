﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StuMarkshit
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            load();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ins = "insert into list values('" + textBox1.Text + "','" + textBox2.Text + "','" + comboBox1.Text + "')";
            SqlDataAdapter adapter = new SqlDataAdapter(ins, Class1.conn);
            DataTable dt1 = new DataTable();
            adapter.Fill(dt1);
            MessageBox.Show("Record insert");
            Clear();
            load();
        }
        public void Clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            comboBox1.Text = "";
            textBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void load()
        {
            string sel = "select * from list ";
            SqlDataAdapter da = new SqlDataAdapter(sel, Class1.conn);
            DataTable dt = new DataTable();

            da.Fill(dt);
            int n = dt.Rows.Count - 1;
            textBox2.Text = (int.Parse(dt.Rows[n]["rolno"].ToString()) + 1).ToString();
            }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
    }
