﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StuMarkshit
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ins = "insert into list values('"+textBox1.Text+"','"+textBox2.Text+"','"+comboBox1.Text+"')";
            SqlDataAdapter adapter = new SqlDataAdapter(ins,Class1.conn);
            DataTable dt1 = new DataTable();
            adapter.Fill(dt1);
            MessageBox.Show("Record insert");
            Clear();
            load();

        }
      public  void Clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.Text = "";
            textBox1.Focus();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Clear();
            /*
             * datasource 
             * select da.fill .ds=dt .dm=meterno"
             * 
        }

    private void Form2_Load(object sender, EventArgs e)
    {
            //if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && comboBox1.Text != "")
            //{
            //   try
            // {

            load();
           
        //}
    }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); 
        }
        private void load()
        {
            string sel = "select * from list ";
            SqlDataAdapter da = new SqlDataAdapter(sel, Class1.conn);
            DataTable dt = new DataTable();

            da.Fill(dt);
            int n = dt.Rows.Count - 1;
            // MessageBox.Show(""+n);
            textBox3.Text = (int.Parse(dt.Rows[n]["rolno"].ToString()) + 1).ToString();
            //}
        }
    }
}
