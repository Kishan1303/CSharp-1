﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace marksheet1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            string sel = "select * from student s , res r where s.nm = r.nm";
            SqlDataAdapter da1 = new SqlDataAdapter(sel, Class1.cs);
            DataTable dt = new DataTable();
            da1.Fill(dt);
           
            dataGridView1.DataSource = dt;

        }



    }
}


