﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace marksheet1
{
    public partial class Form3 : Form
    {
        int m1, m2, m3, m4, total, per;
        String result, gread;

       


        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string sql = "select * from student";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sql, Class1.cs);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            //comboBox1.DataSource = dataTable;
            //comboBox1.DisplayMember = "nm";
            disp();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string sql2 = "select * from res where nm = '" + textBox5.Text + "'";
            SqlDataAdapter da2 = new SqlDataAdapter(sql2, Class1.cs);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);
            if (dt2.Rows.Count > 0)
            {
                MessageBox.Show("alraady exit!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void cal()
        {
            m1 = Convert.ToInt32(textBox1.Text);
            m2 = Convert.ToInt32(textBox2.Text);
            m3 = Convert.ToInt32(textBox3.Text);
            m4 = Convert.ToInt32(textBox4.Text);

            total = m1 + m2 + m3 + m4;
            per = total / 4;
            if (per <= 100 || per > 80)
            {
                result = "Pass";
                gread = "A";
            }
            else if (per <= 80 || per > 60)
            {
                result = "Pass";
                gread = "B";
            }
            else if (per <= 60 || per > 40)
            {
                result = "Pass";
                gread = "C";
            }
            else
            {
                result = "Fail";

            }
        }
        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox1.Focus();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            cal();
            String ins = "insert into res values('"+textBox5.Text+"','" + Convert.ToInt32(textBox1.Text) + "','" + Convert.ToInt32(textBox2.Text) + "','" + Convert.ToInt32(textBox3.Text) + "','" + Convert.ToInt32(textBox4.Text) + "','" + total + "','" + per + "','" + result + "','" + gread + "')";
            SqlDataAdapter sda = new SqlDataAdapter(ins, Class1.cs);
            DataTable dt = new DataTable();
            int a = sda.Fill(dt);
            if (a <= 1)
            {
                MessageBox.Show("Result Created Successfuly...^_^");
                clear();
                Form4 f4 = new Form4();
                f4.Show();
                this.Hide();
            }
        }
              private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string sel = "select * from re";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cs);
            DataTable t = new DataTable();
            int a = sda.Fill(t);
           // dataGridView1.DataSource = Class1.dt;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dataGridViewRow = dataGridView1.Rows[e.RowIndex];
            MessageBox.Show("Are u want to create result !! ");
            DataGridViewRow r = dataGridView1.Rows[e.RowIndex];

            textBox5.Text = (r.Cells[0].Value.ToString());

            //  Form3 f3 = new Form3();
            // f3.Show();
            //this.Hide();
        }
        public void disp()
        {
            string sel = "select * from student";
            SqlDataAdapter da = new SqlDataAdapter(sel, Class1.cs);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

        }




    }
}
