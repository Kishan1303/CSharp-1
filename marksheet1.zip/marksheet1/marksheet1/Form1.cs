﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace marksheet1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ins = "insert into student values('" + textsnm1.Text + "','" + richTextadd.Text + "','" + textclass.Text + "','" + comboBox1.Text + "','" + textsem.Text + "','" + combocity.Text + "')";
            SqlDataAdapter da = new SqlDataAdapter(ins, Class1.cs);
            DataTable dt = new DataTable();
            int a = da.Fill(dt);
            if (a <= 1)
            {
                MessageBox.Show("Successfuly Inserted...^_^");
                  cl();
                 Form3 f2 = new Form3();
                f2.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Not Inserted...^_^");
            }
           
        }
        private void cl()
        {
            textsnm1.Text = "";
            richTextadd.Text = "";
            textclass.Text = "";
            comboBox1.Text = "";
            textsem.Text = "";
            combocity.Text = "";
            textsnm1.Focus();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            cl();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f2 = new Form3();
            f2.Show();
            this.Hide();
        }
    }
}
