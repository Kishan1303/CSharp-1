﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace marksheet1
{
    internal class Class1
    {
        public static SqlConnection cs = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\marksheet.mdf;Integrated Security=True;Connect Timeout=30");
     //   public static DataTable dt = new DataTable();
        
    }
}
