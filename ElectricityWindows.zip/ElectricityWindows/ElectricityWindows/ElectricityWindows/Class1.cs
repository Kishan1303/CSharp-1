﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace ElectricityWindows
{
    internal class Class1
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\CSharp\ElectricityWindows\ElectricityWindows\ElectricityWindows\bin\electricity1.mdf;Integrated Security=True;Connect Timeout=30");

    }
}
