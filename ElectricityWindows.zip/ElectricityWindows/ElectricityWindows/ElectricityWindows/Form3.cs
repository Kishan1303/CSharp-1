﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace ElectricityWindows
{
    public partial class Form3 : Form
    {
     public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string sql = "select * from customer1 ";
            SqlDataAdapter da = new SqlDataAdapter(sql,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "meterno";
        }

            

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
        public void clear()
        {
            textBox2.Text = "";
            textBox1.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox1.Focus();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int total;
            if(textBox1.Text!="")
            {
                total = (int.Parse(textBox2.Text) - int.Parse(textBox1.Text))*10;
            }
            else
            {
                total=int.Parse(textBox2.Text)*10;
            }
            MessageBox.Show("Amount :" + total);
            string sql = "insert into bill1 values('" + comboBox1.Text + "','" + textBox1.Text + "','"+textBox2.Text+"','"+comboBox2.Text+"')";
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(sql,Class1.cn);
            DataTable dt = new DataTable();
            sqlAdapter.Fill(dt);
            textBox2.Text = "";
            comboBox1.Focus();
            comboBox1.ResetText();
            comboBox2.ResetText();
            textBox1.ResetText();
            textBox2.ResetText();
           

            this.Refresh();
            
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Form1 form1 = new Form1();
                form1.Show();
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s = "select * from bill1 where meterno='" + comboBox1.Text + "'";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(s, Class1.cn);
            DataTable dt = new DataTable(); 
            sqlDataAdapter.Fill(dt);
            int n = dt.Rows.Count-1;
            if(dt.Rows.Count >0)
            {
                textBox1.Text = dt.Rows[n]["cuu_unit"].ToString();
            }
            else
            {
                textBox1.Text = "0";
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s2 = "select * from bill1 where month='" + comboBox2.Text + "' and meterno='"+comboBox1.Text+"'";
            SqlDataAdapter da = new SqlDataAdapter(s2, Class1.cn);
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            if(dataTable.Rows.Count > 0)
            {
                MessageBox.Show("Already Done");
            }
            else
            {
                string s3 ="select * from bill1 where month ='"+comboBox2.Text+"'";
                SqlDataAdapter da2 = new SqlDataAdapter(s3, Class1.cn);
                DataTable dataTable2 = new DataTable();
                da2.Fill(dataTable2);
            }
        }
       
    }
}
