﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace ElectricityWindows
{
    public partial class Form2 : Form
    {
     
      
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
           

        }

        private void ButSub_Click(object sender, EventArgs e)
        {
            if (textCus1.Text != "" && textMeter1.Text != "")
            {
                string sql = "select * from customer1 where meterno ='"+textMeter1.Text+"'"; 
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt1 = new DataTable();
                da.Fill(dt1);
                if (dt1.Rows.Count == 0)
                {
                    string ins = "insert into customer1 values('" + textCus1.Text + "','" + textMeter1.Text + "')";
                    SqlDataAdapter da1 = new SqlDataAdapter(ins, Class1.cn);
                    DataTable dt2 = new DataTable();
                    da1.Fill(dt2);
                    MessageBox.Show("Customer add");
                    this.Hide();
                    Form1 f1 = new Form1();
                    f1.Show();

                }
                else
                {

                    MessageBox.Show("Duplicate no");

                }
            }
            else
            {
                MessageBox.Show("Plz Enter Value");
            }
        }

          

            private void button1_Click(object sender, EventArgs e)
            {

                textCus1.Text = "";
                textMeter1.Text = "";
                textCus1.Focus();
            }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Form1 form1 = new Form1();
                form1.Show();
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

    }



    }

